package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiApi
import com.example.data.database.CareTakerDatabase
import com.example.data.model.*
import com.example.data.repository.CareTakerRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class CareTakerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CareTakerRepository
    val userProfile: StateFlow<UserProfile?>
    val achievements: StateFlow<List<Achievement>>
    val allHealthLogs: StateFlow<List<HealthLog>>

    // Selected date (defaults to today in YYYY-MM-DD)
    private val _currentDate = MutableStateFlow(getTodayDateString())
    val currentDate: StateFlow<String> = _currentDate.asStateFlow()

    // Daily tasks for current date
    private val _dailyTasks = MutableStateFlow<List<DailyTask>>(emptyList())
    val dailyTasks: StateFlow<List<DailyTask>> = _dailyTasks.asStateFlow()

    // AI Coach advice message
    private val _aiCoachMessage = MutableStateFlow("Hi! I am your Care Taker AI Health Coach. Let's make today a great day!")
    val aiCoachMessage: StateFlow<String> = _aiCoachMessage.asStateFlow()

    // Is AI loading advice
    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    // Dark mode setting
    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Reminders enabled setting
    private val _remindersEnabled = MutableStateFlow(true)
    val remindersEnabled: StateFlow<Boolean> = _remindersEnabled.asStateFlow()

    // Active screen (WELCOME, ONBOARDING, HOME, STATS, PROFILE, SETTINGS, AI_COACH)
    private val _currentScreen = MutableStateFlow(Screen.WELCOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Health Score calculation (0-100)
    private val _todayHealthScore = MutableStateFlow(80)
    val todayHealthScore: StateFlow<Int> = _todayHealthScore.asStateFlow()

    // Localized UI state/dialog events
    private val _levelUpEvent = MutableStateFlow<Int?>(null) // level number if just leveled up
    val levelUpEvent: StateFlow<Int?> = _levelUpEvent.asStateFlow()

    private val _achievementUnlockedEvent = MutableStateFlow<Achievement?>(null)
    val achievementUnlockedEvent: StateFlow<Achievement?> = _achievementUnlockedEvent.asStateFlow()

    enum class Screen {
        WELCOME, ONBOARDING, HOME, STATS, PROFILE, SETTINGS, AI_COACH
    }

    init {
        val database = CareTakerDatabase.getDatabase(application)
        repository = CareTakerRepository(database.careTakerDao())
        userProfile = repository.userProfile.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )
        achievements = repository.achievements.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
        allHealthLogs = repository.allHealthLogs.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Observe profile to check onboarding state and handle streak checks
        viewModelScope.launch {
            userProfile.collect { profile ->
                if (profile != null) {
                    if (profile.isOnboarded) {
                        // Perform daily streak / task generation
                        checkAndTransitionDay(profile)
                    }
                } else {
                    // Pre-populate standard achievements if they do not exist
                    initDefaultAchievements()
                }
            }
        }

        // Observe selected date and load its tasks
        viewModelScope.launch {
            currentDate.collect { date ->
                loadTasksForDate(date)
            }
        }

        // Keep dynamic health score updated
        viewModelScope.launch {
            combine(dailyTasks, allHealthLogs) { tasks, logs ->
                calculateHealthScore(tasks, logs)
            }.collect { score ->
                _todayHealthScore.value = score
            }
        }
    }

    fun dismissLevelUp() {
        _levelUpEvent.value = null
    }

    fun dismissAchievement() {
        _achievementUnlockedEvent.value = null
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun toggleReminders() {
        _remindersEnabled.value = !_remindersEnabled.value
    }

    fun setScreen(screen: Screen) {
        _currentScreen.value = screen
    }

    /**
     * Completes onboarding and initializes the user profile & routine tasks.
     */
    fun completeOnboarding(
        name: String,
        age: Int,
        gender: String,
        height: Float,
        weight: Float,
        goal: String,
        wakeUpTime: String,
        sleepTime: String,
        preferredMealTimes: String,
        dailyWaterGoal: Float,
        activityLevel: String
    ) {
        viewModelScope.launch {
            val todayStr = getTodayDateString()
            val newProfile = UserProfile(
                id = 1,
                name = name,
                age = age,
                gender = gender,
                height = height,
                weight = weight,
                goal = goal,
                wakeUpTime = wakeUpTime,
                sleepTime = sleepTime,
                preferredMealTimes = preferredMealTimes,
                dailyWaterGoal = dailyWaterGoal,
                activityLevel = activityLevel,
                isOnboarded = true,
                level = 1,
                xp = 0,
                coins = 100, // starting coins
                streak = 1,
                lastActiveDate = todayStr
            )
            repository.saveUserProfile(newProfile)

            // Pre-generate standard tasks
            generateTasksForDate(todayStr, goal, wakeUpTime, sleepTime, preferredMealTimes)

            // Trigger First Day Achievement
            unlockAchievement("FIRST_DAY")

            // Request Custom Routines from AI Coach using Gemini
            generateAiRoutineFromCoach(newProfile)

            // Go to Home screen
            _currentScreen.value = Screen.HOME
        }
    }

    /**
     * Triggered when completing a task
     */
    fun completeTask(task: DailyTask) {
        viewModelScope.launch {
            val updatedTask = task.copy(
                completedCount = task.completedCount + 1,
                isCompleted = (task.completedCount + 1) >= task.targetCount
            )
            repository.updateDailyTask(updatedTask)

            // Earn rewards if it was not already completed
            if (!task.isCompleted && updatedTask.isCompleted) {
                rewardUser(task.pointsXp, task.pointsCoins)

                // Check achievements based on task completions
                checkTaskSpecificAchievements(task.codeName)
            }

            // Reload tasks
            loadTasksForDate(currentDate.value)
        }
    }

    /**
     * Resets a task's progress
     */
    fun decrementTask(task: DailyTask) {
        viewModelScope.launch {
            if (task.completedCount <= 0) return@launch
            val newCount = task.completedCount - 1
            val updatedTask = task.copy(
                completedCount = newCount,
                isCompleted = newCount >= task.targetCount
            )
            repository.updateDailyTask(updatedTask)
            loadTasksForDate(currentDate.value)
        }
    }

    /**
     * Log details such as Weight, Water intake, Sleep hours, Exercise mins or Mood
     */
    fun logMetric(type: String, value: Float, notes: String = "") {
        viewModelScope.launch {
            val todayStr = getTodayDateString()
            val newLog = HealthLog(
                date = todayStr,
                type = type,
                value = value,
                notes = notes
            )
            repository.addHealthLog(newLog)

            // If water logged, update our water task if it exists for today
            if (type == "WATER") {
                val tasks = _dailyTasks.value
                val waterTask = tasks.find { it.codeName == "DRINK_WATER" }
                if (waterTask != null) {
                    val progressInc = (value / 250f).toInt() // assume 250ml per glass
                    if (progressInc > 0) {
                        val newCompleted = (waterTask.completedCount + progressInc).coerceAtMost(waterTask.targetCount)
                        val updated = waterTask.copy(
                            completedCount = newCompleted,
                            isCompleted = newCompleted >= waterTask.targetCount
                        )
                        repository.updateDailyTask(updated)
                        if (!waterTask.isCompleted && updated.isCompleted) {
                            rewardUser(waterTask.pointsXp, waterTask.pointsCoins)
                            unlockAchievement("WATER_MASTER")
                        }
                    }
                }
            }

            // If sleep logged, update sleep task
            if (type == "SLEEP") {
                val tasks = _dailyTasks.value
                val sleepTask = tasks.find { it.codeName == "SLEEP" }
                if (sleepTask != null && value >= 7f) {
                    val updated = sleepTask.copy(completedCount = 1, isCompleted = true)
                    repository.updateDailyTask(updated)
                    if (!sleepTask.isCompleted) {
                        rewardUser(sleepTask.pointsXp, sleepTask.pointsCoins)
                        unlockAchievement("SLEEP_CHAMPION")
                    }
                }
            }

            // If exercise logged, update exercise/walk tasks
            if (type == "EXERCISE") {
                val tasks = _dailyTasks.value
                val exTask = tasks.find { it.codeName == "EXERCISE" }
                if (exTask != null) {
                    val updated = exTask.copy(completedCount = 1, isCompleted = true)
                    repository.updateDailyTask(updated)
                    if (!exTask.isCompleted) {
                        rewardUser(exTask.pointsXp, exTask.pointsCoins)
                        unlockAchievement("FITNESS_HERO")
                    }
                }
            }

            // Trigger dynamic score calculation update
            loadTasksForDate(currentDate.value)
        }
    }

    /**
     * Directly update profile fields from Settings or Profile view
     */
    fun updateProfileDirect(
        name: String,
        age: Int,
        gender: String,
        height: Float,
        weight: Float,
        goal: String,
        dailyWaterGoal: Float
    ) {
        viewModelScope.launch {
            val current = userProfile.value ?: return@launch
            val updated = current.copy(
                name = name,
                age = age,
                gender = gender,
                height = height,
                weight = weight,
                goal = goal,
                dailyWaterGoal = dailyWaterGoal
            )
            repository.saveUserProfile(updated)

            // Log the new weight as a history metric
            logMetric("WEIGHT", weight, "Profile Update")
        }
    }

    /**
     * Ask Gemini for custom encouragement/health tip based on profile and stats
     */
    fun askAiCoach(userQuestion: String = "") {
        viewModelScope.launch {
            _isAiLoading.value = true
            val profile = userProfile.value
            val tasks = _dailyTasks.value
            val score = _todayHealthScore.value

            val completedTasksCount = tasks.count { it.isCompleted }
            val totalTasksCount = tasks.size

            val sysInstruction = """
                You are Care Taker, an AI health coach game companion. Your tone is incredibly supportive, friendly, encouraging, and gamified. You NEVER shame the user. 
                Keep your messages highly concise, energetic, and visually appealing (use 2-3 short bullet points, positive spacing, bold text).
                Refer to game elements like XP, level, coins, and streaks to reward the user.
            """.trimIndent()

            val contextPrompt = if (userQuestion.isEmpty()) {
                """
                    Write a daily supportive and gamified coaching tip for ${profile?.name ?: "Champion"}.
                    Current Level: ${profile?.level ?: 1}, Streak: ${profile?.streak ?: 1} days.
                    Today's health score: $score/100.
                    Completed tasks: $completedTasksCount/$totalTasksCount.
                    Fitness goal: ${profile?.goal ?: "Stay Healthy"}.
                    Water goal: ${profile?.dailyWaterGoal ?: 2.5f} Liters.
                    Activity level: ${profile?.activityLevel ?: "Moderate"}.
                    Give them a motivating push to finish their remaining missions!
                """.trimIndent()
            } else {
                """
                    The user ${profile?.name ?: "Champion"} is asking: "$userQuestion"
                    Context about them: Goal is ${profile?.goal ?: "Stay healthy"}, Health Score is $score, Level is ${profile?.level ?: 1}, Streak is ${profile?.streak ?: 1}.
                    Provide a highly helpful, health-conscious, gamified answer supporting their goal.
                """.trimIndent()
            }

            val responseText = GeminiApi.generateContent(sysInstruction, contextPrompt)
            _aiCoachMessage.value = responseText
            _isAiLoading.value = false
        }
    }

    // --- Private Helper Methods ---

    private fun loadTasksForDate(date: String) {
        viewModelScope.launch {
            repository.getDailyTasks(date).collect { tasks ->
                _dailyTasks.value = tasks
            }
        }
    }

    /**
     * Prepopulate achievements table with static achievements if it's empty
     */
    private suspend fun initDefaultAchievements() {
        val existing = repository.getAchievementsDirect()
        if (existing.isEmpty()) {
            val defaults = listOf(
                Achievement("FIRST_DAY", "First Steps", "Started your Care Taker health journey!"),
                Achievement("STREAK_7", "Week of Fire", "Reached a 7-day healthy streak!"),
                Achievement("STREAK_30", "Iron Will", "Maintained a 30-day healthy streak!"),
                Achievement("DAYS_100", "Centurion Coach", "Completed 100 healthy days!"),
                Achievement("WATER_MASTER", "Hydro King", "Achieved your daily water intake target!"),
                Achievement("SLEEP_CHAMPION", "Dream Weaver", "Slept on time and met recovery targets."),
                Achievement("FITNESS_HERO", "Apex Athlete", "Completed your custom exercise missions."),
                Achievement("HEALTHY_LIFESTYLE", "Ascended Care", "Completed 50 total healthy missions!")
            )
            repository.saveAchievements(defaults)
        }
    }

    /**
     * Checks if the day has changed since last active. If yes, records metrics and manages streaks.
     */
    private suspend fun checkAndTransitionDay(profile: UserProfile) {
        val todayStr = getTodayDateString()
        val lastActive = profile.lastActiveDate

        if (lastActive != todayStr) {
            // Day transition has occurred!
            val updatedStreak = if (lastActive.isEmpty()) {
                1
            } else {
                val isYesterday = isYesterday(lastActive)
                if (isYesterday) profile.streak + 1 else 1
            }

            // Save yesterday's final health score as a log metric before clearing
            if (lastActive.isNotEmpty()) {
                // Compute yesterday's tasks score
                val yesterdayTasks = repository.getDailyTasksDirect(lastActive)
                val yesterdayLogs = repository.getHealthLogsByType("HEALTH_SCORE") // mock check or direct count
                val yesterdayScore = calculateHealthScore(yesterdayTasks, emptyList())
                repository.addHealthLog(HealthLog(date = lastActive, type = "HEALTH_SCORE", value = yesterdayScore.toFloat(), notes = "Daily Final"))
            }

            // Update user profile active date and streak
            val updatedProfile = profile.copy(
                lastActiveDate = todayStr,
                streak = updatedStreak
            )
            repository.saveUserProfile(updatedProfile)

            // Generate today's blank tasks
            generateTasksForDate(
                todayStr,
                profile.goal,
                profile.wakeUpTime,
                profile.sleepTime,
                profile.preferredMealTimes
            )

            // Handle Streak Achievements
            if (updatedStreak >= 7) unlockAchievement("STREAK_7")
            if (updatedStreak >= 30) unlockAchievement("STREAK_30")
            if (updatedStreak >= 100) unlockAchievement("DAYS_100")

            // Update selected date
            _currentDate.value = todayStr
        }
    }

    /**
     * Helper to generate default missions for a specific date
     */
    private suspend fun generateTasksForDate(
        date: String,
        goal: String,
        wakeUpTime: String,
        sleepTime: String,
        preferredMealTimes: String
    ) {
        val existing = repository.getDailyTasksDirect(date)
        if (existing.isNotEmpty()) return

        val waterTarget = when (goal) {
            "Weight Loss" -> 10 // glasses (~250ml each)
            "Stay Healthy" -> 8
            "Muscle Gain" -> 10
            else -> 8
        }

        val tasks = listOf(
            DailyTask(date = date, codeName = "WAKE_UP", title = "Wake Up on time ($wakeUpTime)", targetCount = 1),
            DailyTask(date = date, codeName = "DRINK_WATER", title = "Drink Water", targetCount = waterTarget),
            DailyTask(date = date, codeName = "BREAKFAST", title = "🍳 Healthy Breakfast", targetCount = 1),
            DailyTask(date = date, codeName = "WALK", title = "🚶 Take a 10-Min Walk", targetCount = 1),
            DailyTask(date = date, codeName = "EXERCISE", title = "💪 Daily Exercise", targetCount = 1),
            DailyTask(date = date, codeName = "FRUIT", title = "🍎 Eat Fresh Fruit", targetCount = 1),
            DailyTask(date = date, codeName = "LUNCH", title = "🍛 Energizing Lunch", targetCount = 1),
            DailyTask(date = date, codeName = "READ_RELAX", title = "📚 Offline Relaxation or Reading", targetCount = 1),
            DailyTask(date = date, codeName = "DINNER", title = "🥗 Healthy Dinner", targetCount = 1),
            DailyTask(date = date, codeName = "SLEEP", title = "😴 Sleep on time ($sleepTime)", targetCount = 1)
        )
        repository.saveDailyTasks(tasks)
    }

    /**
     * Rewarding algorithm with XP and Coins
     */
    private suspend fun rewardUser(xpGained: Int, coinsGained: Int) {
        val current = userProfile.value ?: return
        val newXp = current.xp + xpGained
        val newCoins = current.coins + coinsGained

        // 100 XP per level
        val newLevel = (newXp / 100) + 1

        val updated = current.copy(
            xp = newXp,
            coins = newCoins,
            level = newLevel
        )
        repository.saveUserProfile(updated)

        if (newLevel > current.level) {
            _levelUpEvent.value = newLevel
        }

        // Check if healthy lifestyle achievement is unlocked
        val allCompleted = repository.allHealthLogs.first().size // simplified check or task counts
        if (allCompleted >= 50) {
            unlockAchievement("HEALTHY_LIFESTYLE")
        }
    }

    private suspend fun unlockAchievement(codeName: String) {
        val items = repository.getAchievementsDirect()
        val match = items.find { it.codeName == codeName }
        if (match != null && !match.isUnlocked) {
            val updated = match.copy(isUnlocked = true, unlockedDate = getTodayDateString())
            repository.updateAchievement(updated)
            _achievementUnlockedEvent.value = updated
        }
    }

    private fun checkTaskSpecificAchievements(codeName: String) {
        viewModelScope.launch {
            when (codeName) {
                "DRINK_WATER" -> unlockAchievement("WATER_MASTER")
                "SLEEP" -> unlockAchievement("SLEEP_CHAMPION")
                "EXERCISE" -> unlockAchievement("FITNESS_HERO")
            }
        }
    }

    /**
     * Custom Routine Query to Gemini API
     */
    private fun generateAiRoutineFromCoach(profile: UserProfile) {
        viewModelScope.launch {
            val systemPrompt = "You are Care Taker, an expert AI Health Coach. Generate a customized daily routine."
            val userPrompt = """
                My name is ${profile.name}. I am a ${profile.age} year old ${profile.gender}.
                My height is ${profile.height} cm and my weight is ${profile.weight} kg.
                My main health goal is ${profile.goal}.
                I wake up at ${profile.wakeUpTime} and sleep at ${profile.sleepTime}.
                My meal times are: ${profile.preferredMealTimes}.
                My daily water goal is ${profile.dailyWaterGoal} L, with an activity level of ${profile.activityLevel}.
                Generate a personalized daily routine with key reminders and motivational items for me in brief.
            """.trimIndent()

            val routineAdvice = GeminiApi.generateContent(systemPrompt, userPrompt)
            _aiCoachMessage.value = routineAdvice
        }
    }

    /**
     * Dynamically calculates a health score based on tasks completed, water logged, exercise logged, and mood
     */
    private fun calculateHealthScore(tasks: List<DailyTask>, logs: List<HealthLog>): Int {
        if (tasks.isEmpty()) return 80

        var score = 0
        val todayStr = getTodayDateString()
        val todayLogs = logs.filter { it.date == todayStr }

        // 1. Task Completion ratio (max 40 points)
        val completedRatio = tasks.count { it.isCompleted }.toFloat() / tasks.size.toFloat()
        score += (completedRatio * 40).toInt()

        // 2. Water Intake progress (max 15 points)
        val waterLogSum = todayLogs.filter { it.type == "WATER" }.sumOf { it.value.toDouble() }.toFloat()
        val profileWaterGoal = (userProfile.value?.dailyWaterGoal ?: 2.5f) * 1000f // in ml
        if (profileWaterGoal > 0f) {
            val waterRatio = (waterLogSum / profileWaterGoal).coerceAtMost(1f)
            score += (waterRatio * 15).toInt()
        } else {
            score += 10
        }

        // 3. Sleep progress (max 15 points)
        val sleepLog = todayLogs.find { it.type == "SLEEP" }
        if (sleepLog != null) {
            val sleepHours = sleepLog.value
            val sleepScore = (sleepHours / 8f).coerceAtMost(1f) * 15
            score += sleepScore.toInt()
        } else {
            val sleepCompleted = tasks.find { it.codeName == "SLEEP" }?.isCompleted == true
            score += if (sleepCompleted) 15 else 5
        }

        // 4. Exercise progress (max 15 points)
        val exerciseLog = todayLogs.find { it.type == "EXERCISE" }
        if (exerciseLog != null) {
            val mins = exerciseLog.value
            val exScore = (mins / 30f).coerceAtMost(1f) * 15
            score += exScore.toInt()
        } else {
            val exCompleted = tasks.find { it.codeName == "EXERCISE" }?.isCompleted == true
            score += if (exCompleted) 15 else 5
        }

        // 5. Mood Log points (max 15 points)
        val moodLog = todayLogs.find { it.type == "MOOD" }
        if (moodLog != null) {
            score += when (moodLog.notes.lowercase()) {
                "happy", "energetic", "calm" -> 15
                "tired", "focused" -> 12
                "stressed", "sad" -> 8
                else -> 10
            }
        } else {
            score += 5 // default baseline
        }

        return score.coerceIn(0, 100)
    }

    private fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    private fun isYesterday(dateStr: String): Boolean {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = sdf.parse(dateStr) ?: return false
            val cal1 = Calendar.getInstance().apply { time = date }
            val cal2 = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
            cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                    cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
        } catch (e: Exception) {
            false
        }
    }
}
