package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Colors
val PrimaryLight = Color(0xFF0D9488) // Mint Teal
val SecondaryLight = Color(0xFF0F766E)
val TertiaryLight = Color(0xFF10B981) // Emerald Green
val BackgroundLight = Color(0xFFF1F5F9)
val SurfaceLight = Color(0xFFFFFFFF)

// Obsidian Dark Theme Colors
val PrimaryDark = Color(0xFF00F2FE) // Neon Cyan
val SecondaryDark = Color(0xFF4ADE80) // Lime Emerald Green
val TertiaryDark = Color(0xFF00FFCC) // Aqua Glow
val BackgroundDark = Color(0xFF080D16) // Cosmic Black
val SurfaceDark = Color(0xFF111A2E) // Deep Slate Card

// Specialized Gradient/Glow Colors
val GradientStart = Color(0xFF00F2FE)
val GradientEnd = Color(0xFF4FACFE)
val AccentLime = Color(0xFF34D399)
val GlassCardBg = Color(0x1F1E293B)
val GlassCardBorder = Color(0x3300FFCC)
