package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.UserProfile
import com.example.data.model.Achievement
import com.example.data.model.DailyTask
import com.example.data.model.HealthLog
import com.example.ui.CareTakerViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import java.util.Calendar

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: CareTakerViewModel = viewModel()
            val isDark by viewModel.isDarkMode.collectAsStateWithLifecycle()

            MyApplicationTheme(darkTheme = isDark) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CareTakerApp(viewModel)
                }
            }
        }
    }
}

@Composable
fun CareTakerApp(viewModel: CareTakerViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val levelUpBy by viewModel.levelUpEvent.collectAsStateWithLifecycle()
    val achievementUnlocked by viewModel.achievementUnlockedEvent.collectAsStateWithLifecycle()
    val isDark by viewModel.isDarkMode.collectAsStateWithLifecycle()

    // Base background with subtle glowing radial gradients
    val baseBackgroundBrush = if (isDark) {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFF070B14),
                Color(0xFF0F172A),
                Color(0xFF1E293B)
            )
        )
    } else {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFFF1F5F9),
                Color(0xFFE2E8F0),
                Color(0xFFCBD5E1)
            )
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(baseBackgroundBrush)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Crossfade animation between screens
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                fadeIn(animationSpec = tween(400)) togetherWith fadeOut(animationSpec = tween(400))
            },
            label = "ScreenTransition"
        ) { screen ->
            when (screen) {
                CareTakerViewModel.Screen.WELCOME -> WelcomeScreen(viewModel)
                CareTakerViewModel.Screen.ONBOARDING -> OnboardingScreen(viewModel)
                CareTakerViewModel.Screen.HOME -> HomeScreen(viewModel)
                CareTakerViewModel.Screen.STATS -> StatsScreen(viewModel)
                CareTakerViewModel.Screen.PROFILE -> ProfileScreen(viewModel)
                CareTakerViewModel.Screen.SETTINGS -> SettingsScreen(viewModel)
                CareTakerViewModel.Screen.AI_COACH -> AiCoachScreen(viewModel)
            }
        }

        // --- LEVEL UP OVERLAY DIALOG ---
        levelUpBy?.let { level ->
            LevelUpOverlay(level = level) {
                viewModel.dismissLevelUp()
            }
        }

        // --- ACHIEVEMENT UNLOCKED DIALOG ---
        achievementUnlocked?.let { ach ->
            AchievementUnlockedOverlay(achievement = ach) {
                viewModel.dismissAchievement()
            }
        }
    }
}

// ==========================================
// 1. WELCOME SCREEN
// ==========================================
@Composable
fun WelcomeScreen(viewModel: CareTakerViewModel) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()

    LaunchedEffect(profile) {
        delay(3000) // Wait for 3 seconds
        if (profile != null && profile!!.isOnboarded) {
            viewModel.setScreen(CareTakerViewModel.Screen.HOME)
        } else {
            viewModel.setScreen(CareTakerViewModel.Screen.ONBOARDING)
        }
    }

    // Scale animation for glowing background circle
    val infiniteTransition = rememberInfiniteTransition(label = "PulseWelcome")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseGlow"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        // Glowing background orb
        Box(
            modifier = Modifier
                .size(300.dp)
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0x3300F2FE),
                                Color(0x114ADE80),
                                Color.Transparent
                            )
                        ),
                        radius = size.width / 2 * pulseScale
                    )
                }
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Hero App Banner
            Card(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.5.dp, Brush.linearGradient(listOf(Color(0xFF00F2FE), Color(0xFF4ADE80)))),
                modifier = Modifier
                    .size(160.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .align(Alignment.CenterHorizontally)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_app_icon),
                    contentDescription = "Care Taker Icon",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Care Taker",
                fontSize = 38.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Your AI Health Coach Game",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.tertiary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Developers Card (Muhammad Faisal Memon & Shamrez Langah)
            GlassCard(
                modifier = Modifier.fillMaxWidth(0.9f),
                borderColor = Color(0x22FFFFFF)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "DEVELOPED BY THE OWNERS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "Muhammad Faisal Memon",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Shamrez Langah",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "« Welcome to Care Taker! We are happy to help you build a healthier and happier life. Your personal health journey starts today. »",
                fontSize = 14.sp,
                lineHeight = 20.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

// ==========================================
// 2. ONBOARDING SCREEN
// ==========================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(viewModel: CareTakerViewModel) {
    var name by remember { mutableStateOf("") }
    var ageStr by remember { mutableStateOf("25") }
    var gender by remember { mutableStateOf("Male") }
    var heightStr by remember { mutableStateOf("175") }
    var weightStr by remember { mutableStateOf("70") }
    var goal by remember { mutableStateOf("Stay Healthy") }
    var wakeUpTime by remember { mutableStateOf("07:00") }
    var sleepTime by remember { mutableStateOf("22:30") }
    var mealTimes by remember { mutableStateOf("08:00, 13:00, 20:00") }
    var waterGoalLiters by remember { mutableStateOf(2.5f) }
    var activityLevel by remember { mutableStateOf("Moderate") }

    val goalsList = listOf("Weight Loss", "Weight Gain", "Stay Healthy", "Better Sleep", "Muscle Gain")
    val genders = listOf("Male", "Female", "Other")
    val activities = listOf("Sedentary", "Moderate", "High", "Athlete")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Welcome banner in Onboarding
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(20.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_hero_banner),
                    contentDescription = "Health Coach Onboarding",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color(0xCC000000))
                            )
                        )
                )
                Text(
                    text = "Personalize Your AI Coach",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                )
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Tell us about yourself",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("What should we call you? (Name)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = ageStr,
                            onValueChange = { ageStr = it.filter { c -> c.isDigit() } },
                            label = { Text("Age") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = heightStr,
                            onValueChange = { heightStr = it },
                            label = { Text("Height (cm)") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = weightStr,
                            onValueChange = { weightStr = it },
                            label = { Text("Weight (kg)") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )
                    }

                    // Gender selector
                    Text("Gender", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        genders.forEach { gen ->
                            val isSelected = gender == gen
                            Button(
                                onClick = { gender = gen },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primary else Color(0x22FFFFFF),
                                    contentColor = if (isSelected) Color.Black else MaterialTheme.colorScheme.onBackground
                                ),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                Text(gen, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Your Wellness Goal",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        goalsList.forEach { g ->
                            val isSelected = goal == g
                            InputChip(
                                selected = isSelected,
                                onClick = { goal = g },
                                label = { Text(g) },
                                colors = InputChipDefaults.inputChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }
                }
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Times & Daily Goals",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = wakeUpTime,
                            onValueChange = { wakeUpTime = it },
                            label = { Text("Wake-up Time") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = sleepTime,
                            onValueChange = { sleepTime = it },
                            label = { Text("Sleep Time") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = mealTimes,
                        onValueChange = { mealTimes = it },
                        label = { Text("Meal Times (comma separated)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // Water Goal Slider
                    Text(
                        text = "Daily Water Goal: ${"%.1f".format(waterGoalLiters)} Liters",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Slider(
                        value = waterGoalLiters,
                        onValueChange = { waterGoalLiters = it },
                        valueRange = 1.0f..5.0f,
                        steps = 8,
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )

                    // Activity Level
                    Text("Activity Level", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        activities.forEach { act ->
                            val isSelected = activityLevel == act
                            Button(
                                onClick = { activityLevel = act },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primary else Color(0x11FFFFFF),
                                    contentColor = if (isSelected) Color.Black else MaterialTheme.colorScheme.onBackground
                                ),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 4.dp)
                            ) {
                                Text(act, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {
                    if (name.trim().isEmpty()) {
                        name = "Champion"
                    }
                    viewModel.completeOnboarding(
                        name = name,
                        age = ageStr.toIntOrNull() ?: 25,
                        gender = gender,
                        height = heightStr.toFloatOrNull() ?: 175f,
                        weight = weightStr.toFloatOrNull() ?: 70f,
                        goal = goal,
                        wakeUpTime = wakeUpTime,
                        sleepTime = sleepTime,
                        preferredMealTimes = mealTimes,
                        dailyWaterGoal = waterGoalLiters,
                        activityLevel = activityLevel
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .clip(RoundedCornerShape(16.dp)),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.Black
                )
            ) {
                Text(
                    text = "Generate My Routine ✨",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ==========================================
// 3. HOME SCREEN
// ==========================================
@Composable
fun HomeScreen(viewModel: CareTakerViewModel) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val tasks by viewModel.dailyTasks.collectAsStateWithLifecycle()
    val score by viewModel.todayHealthScore.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Upper App Header Row (Avatar, Level/Coin counters)
        HomeHeaderRow(profile, viewModel)

        // Main glass scroll container
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                // Circular health meter & Motivational advice in one GlassCard
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(24.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Circular Score Indicator
                            Box(
                                modifier = Modifier.size(110.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularScoreDial(score = score)
                            }

                            Column(
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = getGreetingMessage(),
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Ready to conquer today's wellness missions, ${profile?.name ?: "User"}?",
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                                )
                            }
                        }

                        // Short motivational banner
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0x0C00FFCC), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = "AI Advice",
                                tint = MaterialTheme.colorScheme.tertiary
                            )
                            Text(
                                text = "AI Coach: \"Completing today's walks and water goals boosts your level and earns coins!\"",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.9f)
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Today's Missions 🎯",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            // Tasks List
            items(tasks) { task ->
                TaskCardItem(task = task, onComplete = { viewModel.completeTask(task) })
            }
        }

        // Beautiful standard bottom navigation bar
        CareTakerBottomNavigation(activeScreen = CareTakerViewModel.Screen.HOME, viewModel = viewModel)
    }
}

@Composable
fun HomeHeaderRow(profile: UserProfile?, viewModel: CareTakerViewModel) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // User avatar & levels
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.clickable { viewModel.setScreen(CareTakerViewModel.Screen.PROFILE) }
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.tertiary
                            )
                        )
                    )
                    .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Avatar",
                    tint = Color.Black,
                    modifier = Modifier.size(32.dp)
                )
            }

            Column {
                Text(
                    text = "Lvl ${profile?.level ?: 1}",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                // XP small progress
                val xpCurrent = profile?.xp ?: 0
                val xpNeeded = 100
                Text(
                    text = "$xpCurrent/$xpNeeded XP",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }
        }

        // Stats markers (Coins, Streak)
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Streak
            StatBadge(icon = Icons.Default.LocalFireDepartment, tint = Color(0xFFFF5722), value = "${profile?.streak ?: 1} Days")
            // Coins
            StatBadge(icon = Icons.Default.MonetizationOn, tint = Color(0xFFFFC107), value = "${profile?.coins ?: 0}")
        }
    }
}

@Composable
fun StatBadge(icon: ImageVector, tint: Color, value: String) {
    Row(
        modifier = Modifier
            .background(Color(0x1AFFFFFF), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0x11FFFFFF), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun TaskCardItem(task: DailyTask, onComplete: () -> Unit) {
    val progressPercent = if (task.targetCount > 0) {
        (task.completedCount.toFloat() / task.targetCount.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val isFull = task.isCompleted

    // Map code names to cool icons
    val icon = when (task.codeName) {
        "WAKE_UP" -> Icons.Default.Alarm
        "DRINK_WATER" -> Icons.Default.LocalActivity
        "BREAKFAST" -> Icons.Default.Restaurant
        "WALK" -> Icons.Default.DirectionsWalk
        "EXERCISE" -> Icons.Default.FitnessCenter
        "FRUIT" -> Icons.Default.Spa
        "LUNCH" -> Icons.Default.Restaurant
        "READ_RELAX" -> Icons.Default.MenuBook
        "DINNER" -> Icons.Default.Restaurant
        "SLEEP" -> Icons.Default.Bedtime
        else -> Icons.Default.CheckCircle
    }

    val iconColor = if (isFull) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = if (isFull) Color(0x334ADE80) else Color(0x11FFFFFF)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Task icon
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(Color(0x0DFFFFFF), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = task.title,
                    tint = iconColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = task.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isFull) MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onBackground
                )

                // Progress ratio text and linear progress bar
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Progress: ${task.completedCount}/${task.targetCount}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    )
                    Text(
                        text = "+20 XP  +10 🪙",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }

                LinearProgressIndicator(
                    progress = { progressPercent },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape),
                    color = if (isFull) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                    trackColor = Color(0x11FFFFFF)
                )
            }

            // Complete button / incrementer
            IconButton(
                onClick = onComplete,
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        if (isFull) MaterialTheme.colorScheme.secondary else Color(0x1AFFFFFF),
                        CircleShape
                    )
            ) {
                Icon(
                    imageVector = if (isFull) Icons.Default.Check else Icons.Default.Add,
                    contentDescription = "Complete",
                    tint = if (isFull) Color.Black else MaterialTheme.colorScheme.onBackground
                )
            }
        }
    }
}

// ==========================================
// 4. AI HEALTH COACH (CHAT & ADVICE)
// ==========================================
@Composable
fun AiCoachScreen(viewModel: CareTakerViewModel) {
    val adviceText by viewModel.aiCoachMessage.collectAsStateWithLifecycle()
    val isAiLoading by viewModel.isAiLoading.collectAsStateWithLifecycle()
    var userQuestion by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "AI Health Coach 🤖",
            fontSize = 26.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary
        )

        // Coach Bio
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF00F2FE),
                                    Color(0xFF4ADE80)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Android,
                        contentDescription = "Coach avatar",
                        tint = Color.Black,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Column {
                    Text(
                        text = "Care Taker Coach",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "Interactive Health & Wellness Advisor",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
            }
        }

        // Advisory Display Board
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            GlassCard(
                modifier = Modifier.fillMaxSize(),
                borderColor = Color(0x22FFFFFF)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "HEALTH COACH ADVICE:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )

                    if (isAiLoading) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                                Text(
                                    "Consulting Gemini AI Coach...",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                                )
                            }
                        }
                    } else {
                        Text(
                            text = adviceText,
                            fontSize = 15.sp,
                            lineHeight = 22.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }
        }

        // Question Input Panel
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = userQuestion,
                onValueChange = { userQuestion = it },
                placeholder = { Text("Ask anything about fitness/diet...") },
                modifier = Modifier.weight(1f),
                maxLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary
                )
            )

            Button(
                onClick = {
                    if (userQuestion.trim().isNotEmpty()) {
                        viewModel.askAiCoach(userQuestion)
                        userQuestion = ""
                    } else {
                        viewModel.askAiCoach()
                    }
                },
                modifier = Modifier.height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send"
                )
            }
        }

        CareTakerBottomNavigation(activeScreen = CareTakerViewModel.Screen.AI_COACH, viewModel = viewModel)
    }
}

// ==========================================
// 5. STATISTICS SCREEN (CHARTS)
// ==========================================
@Composable
fun StatsScreen(viewModel: CareTakerViewModel) {
    val logs by viewModel.allHealthLogs.collectAsStateWithLifecycle()
    var selectedFilter by remember { mutableStateOf("Weight") } // "Weight", "Water", "Sleep", "Exercise"
    var showLogDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Progress & Stats 📊",
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )

            // Log Button
            Button(
                onClick = { showLogDialog = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.Black
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Log Daily", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Filters Horizontal Scroller
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Weight", "Water", "Sleep", "Exercise", "Health Score").forEach { filter ->
                val isSelected = selectedFilter == filter
                Button(
                    onClick = { selectedFilter = filter },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.primary else Color(0x11FFFFFF),
                        contentColor = if (isSelected) Color.Black else MaterialTheme.colorScheme.onBackground
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(filter, fontSize = 12.sp)
                }
            }
        }

        // Dynamic Native Canvas Chart Card
        GlassCard(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "$selectedFilter Progress Log",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color(0x08FFFFFF), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    RenderNativeChart(
                        logs = logs,
                        type = selectedFilter.uppercase().replace(" ", "_")
                    )
                }

                Text(
                    text = "Weekly view showing latest logged updates",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Show Log Dialog
        if (showLogDialog) {
            QuickLogDialog(
                onDismiss = { showLogDialog = false },
                onSave = { type, value, notes ->
                    viewModel.logMetric(type, value, notes)
                    showLogDialog = false
                }
            )
        }

        CareTakerBottomNavigation(activeScreen = CareTakerViewModel.Screen.STATS, viewModel = viewModel)
    }
}

// Hand-drawn native Canvas charts for bullet-proof compilation and high performance
@Composable
fun RenderNativeChart(logs: List<HealthLog>, type: String) {
    // Filter out relevant logs
    val filteredLogs = logs.filter { it.type == type }.take(7).reversed()

    if (filteredLogs.isEmpty()) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Outlined.Analytics, contentDescription = null, modifier = Modifier.size(54.dp), tint = Color.Gray)
            Text("No data logged for today yet.", color = Color.Gray, fontSize = 14.sp)
            Text("Tap 'Log Daily' to add records!", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
        }
        return
    }

    val maxVal = (filteredLogs.maxOfOrNull { it.value } ?: 100f).coerceAtLeast(10f)
    val minVal = filteredLogs.minOfOrNull { it.value } ?: 0f

    val strokeColor = MaterialTheme.colorScheme.primary
    val barColor = MaterialTheme.colorScheme.tertiary

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 32.dp)
    ) {
        val width = size.width
        val height = size.height

        val pointCount = filteredLogs.size
        val xStep = if (pointCount > 1) width / (pointCount - 1) else width

        // Draw basic grid line coordinates
        drawLine(
            color = Color(0x22FFFFFF),
            start = Offset(0f, height),
            end = Offset(width, height),
            strokeWidth = 2f
        )
        drawLine(
            color = Color(0x11FFFFFF),
            start = Offset(0f, height / 2),
            end = Offset(width, height / 2),
            strokeWidth = 1f
        )

        val points = filteredLogs.mapIndexed { index, log ->
            val range = (maxVal - minVal).coerceAtLeast(1f)
            val yNorm = (log.value - minVal) / range
            val yPos = height - (yNorm * height * 0.7f) // leave top space
            val xPos = index * xStep
            Offset(xPos, yPos)
        }

        if (type == "WATER" || type == "EXERCISE") {
            // Render beautiful Bar Chart
            val barWidth = (width / pointCount) * 0.4f
            points.forEachIndexed { i, pt ->
                drawRoundRect(
                    color = barColor.copy(alpha = 0.8f),
                    topLeft = Offset(pt.x - barWidth / 2, pt.y),
                    size = Size(barWidth, height - pt.y),
                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                )
                // Draw value tag text
                // Simple dot indicator instead of complex text layout
                drawCircle(color = Color.White, radius = 3.dp.toPx(), center = Offset(pt.x, pt.y - 10f))
            }
        } else {
            // Render beautiful spline Line Chart
            val path = Path().apply {
                points.forEachIndexed { i, pt ->
                    if (i == 0) moveTo(pt.x, pt.y) else lineTo(pt.x, pt.y)
                }
            }

            drawPath(
                path = path,
                color = strokeColor,
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )

            // Draw glowing points
            points.forEach { pt ->
                drawCircle(color = strokeColor, radius = 6.dp.toPx(), center = pt)
                drawCircle(color = Color.White, radius = 3.dp.toPx(), center = pt)
            }
        }
    }
}

// Dialog to quickly input metric logs
@Composable
fun QuickLogDialog(onDismiss: () -> Unit, onSave: (String, Float, String) -> Unit) {
    var type by remember { mutableStateOf("WATER") }
    var valueStr by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    val types = listOf("WATER", "SLEEP", "EXERCISE", "WEIGHT", "MOOD")

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    val value = valueStr.toFloatOrNull() ?: 0f
                    onSave(type, value, note)
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.Black)
            ) {
                Text("Save Record")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
        title = { Text("Log Health Record 📝", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Select Metric Type", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    types.forEach { t ->
                        val isSel = type == t
                        FilterChip(
                            selected = isSel,
                            onClick = { type = t },
                            label = { Text(t) }
                        )
                    }
                }

                val unitLabel = when (type) {
                    "WATER" -> "Amount (ml, e.g., 250)"
                    "SLEEP" -> "Hours (e.g., 7.5)"
                    "EXERCISE" -> "Duration (minutes, e.g., 30)"
                    "WEIGHT" -> "Weight (kg, e.g., 72)"
                    else -> "Mood Scale (1-10)"
                }

                OutlinedTextField(
                    value = valueStr,
                    onValueChange = { valueStr = it },
                    label = { Text(unitLabel) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Notes (Mood, Exercise type, etc.)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        }
    )
}

// ==========================================
// 6. PROFILE & ACHIEVEMENTS SCREEN
// ==========================================
@Composable
fun ProfileScreen(viewModel: CareTakerViewModel) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val achievements by viewModel.achievements.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "My Profile 👤",
            fontSize = 26.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                // Glass Profile Card
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            MaterialTheme.colorScheme.primary,
                                            MaterialTheme.colorScheme.tertiary
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = Color.Black
                            )
                        }

                        Text(
                            text = profile?.name ?: "Champion User",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold
                        )

                        Text(
                            text = "Target: ${profile?.goal ?: "Stay Healthy"}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary
                        )

                        // Divider line
                        HorizontalDivider(color = Color(0x11FFFFFF), thickness = 1.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            ProfileStatItem(label = "Age", value = "${profile?.age ?: 25} yrs")
                            ProfileStatItem(label = "Height", value = "${profile?.height?.toInt() ?: 175} cm")
                            ProfileStatItem(label = "Weight", value = "${profile?.weight?.toInt() ?: 70} kg")
                        }
                    }
                }
            }

            item {
                Text(
                    text = "My Achievements 🏆",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            // Grid of Achievements
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    achievements.chunked(2).forEach { chunk ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            chunk.forEach { ach ->
                                Box(modifier = Modifier.weight(1f)) {
                                    AchievementCard(achievement = ach)
                                }
                            }
                            if (chunk.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        CareTakerBottomNavigation(activeScreen = CareTakerViewModel.Screen.PROFILE, viewModel = viewModel)
    }
}

@Composable
fun ProfileStatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
        Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun AchievementCard(achievement: Achievement) {
    val isUnlocked = achievement.isUnlocked
    val tintColor = if (isUnlocked) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.6f)

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp),
        borderColor = if (isUnlocked) MaterialTheme.colorScheme.primary.copy(alpha = 0.4f) else Color(0x0AFFFFFF)
    ) {
        Column(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = if (isUnlocked) Icons.Default.EmojiEvents else Icons.Default.Lock,
                contentDescription = achievement.title,
                tint = tintColor,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = achievement.title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                color = if (isUnlocked) MaterialTheme.colorScheme.onBackground else Color.Gray
            )
            Text(
                text = achievement.description,
                fontSize = 9.sp,
                lineHeight = 11.sp,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ==========================================
// 7. SETTINGS SCREEN
// ==========================================
@Composable
fun SettingsScreen(viewModel: CareTakerViewModel) {
    val isDark by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val remEnabled by viewModel.remindersEnabled.collectAsStateWithLifecycle()
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()

    var showEditProfile by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Settings ⚙️",
            fontSize = 26.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Preference", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Theme switch
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.toggleDarkMode() }
                                .padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Icon(Icons.Default.DarkMode, contentDescription = null)
                                Text("Dark Theme Mode")
                            }
                            Switch(checked = isDark, onCheckedChange = { viewModel.toggleDarkMode() })
                        }

                        // Notifications toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.toggleReminders() }
                                .padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Icon(Icons.Default.Notifications, contentDescription = null)
                                Text("Reminders Notifications")
                            }
                            Switch(checked = remEnabled, onCheckedChange = { viewModel.toggleReminders() })
                        }
                    }
                }
            }

            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("User Management", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Edit Profile Info
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showEditProfile = true }
                                .padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Icon(Icons.Default.Edit, contentDescription = null)
                                Text("Update Bio and Goal")
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null)
                        }
                    }
                }
            }

            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("About Owners", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)

                        Text("Developed proudly by:", fontSize = 13.sp)
                        Text("• Muhammad Faisal Memon", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("• Shamrez Langah", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Care Taker version 1.0.0 is an offline-capable, gamified health assistant providing secure dynamic routine tracking.",
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        }

        if (showEditProfile && profile != null) {
            EditProfileDialog(
                profile = profile!!,
                onDismiss = { showEditProfile = false },
                onSave = { name, age, gender, h, w, g, water ->
                    viewModel.updateProfileDirect(name, age, gender, h, w, g, water)
                    showEditProfile = false
                }
            )
        }

        CareTakerBottomNavigation(activeScreen = CareTakerViewModel.Screen.SETTINGS, viewModel = viewModel)
    }
}

@Composable
fun EditProfileDialog(
    profile: com.example.data.model.UserProfile,
    onDismiss: () -> Unit,
    onSave: (String, Int, String, Float, Float, String, Float) -> Unit
) {
    var name by remember { mutableStateOf(profile.name) }
    var ageStr by remember { mutableStateOf(profile.age.toString()) }
    var gender by remember { mutableStateOf(profile.gender) }
    var heightStr by remember { mutableStateOf(profile.height.toString()) }
    var weightStr by remember { mutableStateOf(profile.weight.toString()) }
    var goal by remember { mutableStateOf(profile.goal) }
    var waterGoalLiters by remember { mutableStateOf(profile.dailyWaterGoal) }

    val goalsList = listOf("Weight Loss", "Weight Gain", "Stay Healthy", "Better Sleep", "Muscle Gain")

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        name,
                        ageStr.toIntOrNull() ?: 25,
                        gender,
                        heightStr.toFloatOrNull() ?: 175f,
                        weightStr.toFloatOrNull() ?: 70f,
                        goal,
                        waterGoalLiters
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.Black)
            ) {
                Text("Update")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
        title = { Text("Update Profile Info 📝", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = ageStr, onValueChange = { ageStr = it }, label = { Text("Age") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = heightStr, onValueChange = { heightStr = it }, label = { Text("Height (cm)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = weightStr, onValueChange = { weightStr = it }, label = { Text("Weight (kg)") }, modifier = Modifier.fillMaxWidth())

                Text("Your Goal", fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    goalsList.forEach { g ->
                        val isSel = goal == g
                        FilterChip(
                            selected = isSel,
                            onClick = { goal = g },
                            label = { Text(g) }
                        )
                    }
                }

                Text("Water target: ${"%.1f".format(waterGoalLiters)} L", fontWeight = FontWeight.Bold)
                Slider(
                    value = waterGoalLiters,
                    onValueChange = { waterGoalLiters = it },
                    valueRange = 1.0f..5.0f,
                    steps = 8
                )
            }
        }
    )
}

// ==========================================
// CENTRALIZED GLASSMORPHIC CARD COMPONENT
// ==========================================
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    borderColor: Color = Color(0x11FFFFFF),
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.2.dp, borderColor),
        colors = CardDefaults.cardColors(
            containerColor = Color(0x1F1E293B).copy(alpha = 0.6f)
        )
    ) {
        content()
    }
}

// Animated circular dial for health scores
@Composable
fun CircularScoreDial(score: Int) {
    val animatedScore by animateFloatAsState(
        targetValue = score.toFloat(),
        animationSpec = tween(1200, easing = FastOutSlowInEasing),
        label = "HealthScoreAnimation"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidthPx = 10.dp.toPx()
        val diameter = size.minDimension - strokeWidthPx
        val center = Offset(size.width / 2, size.height / 2)

        // Draw background base arc
        drawCircle(
            color = Color(0x11FFFFFF),
            radius = diameter / 2,
            style = Stroke(width = strokeWidthPx)
        )

        // Draw progress arc
        drawArc(
            color = Color(0xFF00F2FE),
            startAngle = -90f,
            sweepAngle = (animatedScore / 100f) * 360f,
            useCenter = false,
            style = Stroke(width = strokeWidthPx, cap = StrokeCap.Round),
            size = Size(diameter, diameter),
            topLeft = Offset(center.x - diameter / 2, center.y - diameter / 2)
        )
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "$score",
            fontSize = 28.sp,
            fontWeight = FontWeight.Black,
            color = Color.White
        )
        Text(
            text = "Score",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.tertiary
        )
    }
}

// Level Up overlay Dialog
@Composable
fun LevelUpOverlay(level: Int, onDismiss: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .clickable { onDismiss() }
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Stars,
                contentDescription = null,
                tint = Color(0xFFFFC107),
                modifier = Modifier.size(100.dp)
            )
            Text(
                text = "LEVEL UP! 🎉",
                fontSize = 34.sp,
                fontWeight = FontWeight.Black,
                color = Color.White
            )
            Text(
                text = "You have reached Level $level!",
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Your AI Coach is impressed. Keep up the amazing work! +100 Coins reward added.",
                color = Color.White.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.Black)
            ) {
                Text("Claim Reward 🪙")
            }
        }
    }
}

// Achievement unlocked overlay
@Composable
fun AchievementUnlockedOverlay(achievement: Achievement, onDismiss: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .clickable { onDismiss() }
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.EmojiEvents,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.size(100.dp)
            )
            Text(
                text = "ACHIEVEMENT UNLOCKED! 🏆",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Text(
                text = achievement.title,
                fontSize = 22.sp,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = achievement.description,
                color = Color.White.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.Black)
            ) {
                Text("Collect Medal 🏅")
            }
        }
    }
}

// Standard M3 dynamic navigation bar
@Composable
fun CareTakerBottomNavigation(activeScreen: CareTakerViewModel.Screen, viewModel: CareTakerViewModel) {
    NavigationBar(
        containerColor = Color(0x0AFFFFFF),
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = activeScreen == CareTakerViewModel.Screen.HOME,
            onClick = { viewModel.setScreen(CareTakerViewModel.Screen.HOME) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Home", fontSize = 11.sp) }
        )

        NavigationBarItem(
            selected = activeScreen == CareTakerViewModel.Screen.AI_COACH,
            onClick = { viewModel.setScreen(CareTakerViewModel.Screen.AI_COACH) },
            icon = { Icon(Icons.Default.SmartToy, contentDescription = "AI Coach") },
            label = { Text("AI Coach", fontSize = 11.sp) }
        )

        NavigationBarItem(
            selected = activeScreen == CareTakerViewModel.Screen.STATS,
            onClick = { viewModel.setScreen(CareTakerViewModel.Screen.STATS) },
            icon = { Icon(Icons.Default.Analytics, contentDescription = "Stats") },
            label = { Text("Stats", fontSize = 11.sp) }
        )

        NavigationBarItem(
            selected = activeScreen == CareTakerViewModel.Screen.PROFILE,
            onClick = { viewModel.setScreen(CareTakerViewModel.Screen.PROFILE) },
            icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
            label = { Text("Profile", fontSize = 11.sp) }
        )

        NavigationBarItem(
            selected = activeScreen == CareTakerViewModel.Screen.SETTINGS,
            onClick = { viewModel.setScreen(CareTakerViewModel.Screen.SETTINGS) },
            icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
            label = { Text("Settings", fontSize = 11.sp) }
        )
    }
}

// Greeting helper based on Hour of Day
fun getGreetingMessage(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when (hour) {
        in 0..11 -> "Good Morning! 🌅"
        in 12..16 -> "Good Afternoon! ☀️"
        else -> "Good Evening! 🌙"
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

