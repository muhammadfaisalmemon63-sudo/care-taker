package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "health_logs")
data class HealthLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // format: "YYYY-MM-DD"
    val type: String, // "WEIGHT", "WATER", "SLEEP", "EXERCISE", "MOOD", "HEALTH_SCORE"
    val value: Float,
    val notes: String = "" // can hold mood text, medicine name, etc.
)
