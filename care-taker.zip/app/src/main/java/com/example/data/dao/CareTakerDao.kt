package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CareTakerDao {

    // --- User Profile Queries ---
    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun getUserProfileFlow(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile WHERE id = 1")
    suspend fun getUserProfile(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserProfile(profile: UserProfile)

    // --- Daily Tasks Queries ---
    @Query("SELECT * FROM daily_tasks WHERE date = :date")
    fun getDailyTasksFlow(date: String): Flow<List<DailyTask>>

    @Query("SELECT * FROM daily_tasks WHERE date = :date")
    suspend fun getDailyTasks(date: String): List<DailyTask>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyTask(task: DailyTask)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyTasks(tasks: List<DailyTask>)

    @Update
    suspend fun updateDailyTask(task: DailyTask)

    @Query("DELETE FROM daily_tasks WHERE date = :date")
    suspend fun deleteDailyTasksForDate(date: String)

    // --- Health Logs Queries ---
    @Query("SELECT * FROM health_logs ORDER BY date DESC, id DESC")
    fun getHealthLogsFlow(): Flow<List<HealthLog>>

    @Query("SELECT * FROM health_logs WHERE type = :type ORDER BY date ASC")
    fun getHealthLogsFlowByType(type: String): Flow<List<HealthLog>>

    @Query("SELECT * FROM health_logs WHERE type = :type ORDER BY date ASC")
    suspend fun getHealthLogsByType(type: String): List<HealthLog>

    @Query("SELECT * FROM health_logs WHERE date = :date AND type = :type")
    suspend fun getHealthLogsForDateAndType(date: String, type: String): List<HealthLog>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHealthLog(log: HealthLog)

    @Query("DELETE FROM health_logs WHERE id = :id")
    suspend fun deleteHealthLogById(id: Int)

    // --- Achievements Queries ---
    @Query("SELECT * FROM achievements")
    fun getAchievementsFlow(): Flow<List<Achievement>>

    @Query("SELECT * FROM achievements")
    suspend fun getAchievements(): List<Achievement>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAchievements(achievements: List<Achievement>)

    @Update
    suspend fun updateAchievement(achievement: Achievement)
}
