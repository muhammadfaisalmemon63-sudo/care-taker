package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.CareTakerDao
import com.example.data.model.*

@Database(
    entities = [
        UserProfile::class,
        DailyTask::class,
        HealthLog::class,
        Achievement::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CareTakerDatabase : RoomDatabase() {

    abstract fun careTakerDao(): CareTakerDao

    companion object {
        @Volatile
        private var INSTANCE: CareTakerDatabase? = null

        fun getDatabase(context: Context): CareTakerDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CareTakerDatabase::class.java,
                    "care_taker_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
