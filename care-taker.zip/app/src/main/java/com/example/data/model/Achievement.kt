package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "achievements")
data class Achievement(
    @PrimaryKey val codeName: String, // e.g., "FIRST_DAY", "STREAK_7", "STREAK_30", "DAYS_100", "WATER_MASTER", "SLEEP_CHAMPION", "FITNESS_HERO", "HEALTHY_LIFESTYLE"
    val title: String,
    val description: String,
    val isUnlocked: Boolean = false,
    val unlockedDate: String = ""
)
