package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val name: String = "",
    val age: Int = 25,
    val gender: String = "Other",
    val height: Float = 170f,
    val weight: Float = 70f,
    val goal: String = "Stay Healthy",
    val wakeUpTime: String = "07:00",
    val sleepTime: String = "22:00",
    val preferredMealTimes: String = "08:00, 13:00, 20:00",
    val dailyWaterGoal: Float = 2.5f,
    val activityLevel: String = "Moderate",
    val isOnboarded: Boolean = false,
    val level: Int = 1,
    val xp: Int = 0,
    val coins: Int = 0,
    val streak: Int = 0,
    val lastActiveDate: String = ""
)
