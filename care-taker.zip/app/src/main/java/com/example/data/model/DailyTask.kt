package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_tasks")
data class DailyTask(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // format: "YYYY-MM-DD"
    val codeName: String, // e.g., "WAKE_UP", "DRINK_WATER", etc.
    val title: String,
    val targetCount: Int = 1,
    val completedCount: Int = 0,
    val isCompleted: Boolean = false,
    val pointsXp: Int = 20,
    val pointsCoins: Int = 10
)
