package com.example.data.api

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiApi {
    private const val TAG = "GeminiApi"
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Queries the Gemini API with a system prompt and user prompt.
     */
    suspend fun generateContent(systemPrompt: String, userPrompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            Log.e(TAG, "Failed to read GEMINI_API_KEY from BuildConfig: ${e.message}")
            ""
        }

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w(TAG, "Gemini API key is not configured. Falling back to simulated AI response.")
            return@withContext getSimulatedResponse(userPrompt)
        }

        try {
            // Construct request payload manually using JSONObject to avoid dependency issues
            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", userPrompt)
                            })
                        })
                    })
                }
                put("contents", contentsArray)

                if (systemPrompt.isNotEmpty()) {
                    put("systemInstruction", JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", systemPrompt)
                            })
                        })
                    })
                }

                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.7)
                })
            }

            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string() ?: ""
                    Log.e(TAG, "API error response: code=${response.code}, body=$errBody")
                    return@withContext "Error: Gemini API responded with ${response.code}. Using local engine instead."
                }

                val bodyStr = response.body?.string() ?: return@withContext "Error: Empty response body."
                val responseJson = JSONObject(bodyStr)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val contentObj = firstCandidate.optJSONObject("content")
                    if (contentObj != null) {
                        val parts = contentObj.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val firstPart = parts.getJSONObject(0)
                            return@withContext firstPart.optString("text", "No text generated.")
                        }
                    }
                }
                "No response from Gemini API."
            }
        } catch (e: Exception) {
            Log.e(TAG, "API network/parse exception: ${e.message}", e)
            "Error: ${e.message}. Falling back to offline assistance."
        }
    }

    /**
     * Generates a realistic health-coach response when the API key is not set or a network error occurs.
     */
    private fun getSimulatedResponse(prompt: String): String {
        return when {
            prompt.contains("routine", ignoreCase = true) -> {
                """
                ✨ Here is your custom Care Taker Routine! ✨
                
                🌅 MORNING MISSION:
                - Wake Up on time (Set for your custom time)
                - Drink Water (Start with 2 full glasses to kickstart metabolism)
                - Balanced Breakfast (Focus on protein and slow-digesting carbs)
                
                🏃 DAYTIME MISSION:
                - Take a brisk 10-minute Walk
                - Drink Water (Fill your daily bottle)
                - Nutritious Lunch
                - Eat Fruit (A healthy snack to keep energy levels high)
                
                🏋️ EVENING MISSION:
                - Exercise (30 minutes of strength or cardio)
                - Healthy Dinner (Lighter, with clean proteins and veggies)
                - Relax or Read (Unwind without screens)
                
                🌃 NIGHT MISSION:
                - Sleep on time to complete your sleep recovery cycle!
                
                🔥 Game Tip: Complete each mission to earn +20 XP and +10 Coins! Level up to unlock healthy achievements.
                """.trimIndent()
            }
            prompt.contains("morning", ignoreCase = true) || prompt.contains("wake", ignoreCase = true) -> {
                "Good morning! Rise and shine. ☀️ Let's start today with 2 glasses of water to hydrate your body. Ready for today's missions?"
            }
            prompt.contains("sleep", ignoreCase = true) || prompt.contains("night", ignoreCase = true) -> {
                "Sleep is the cornerstone of recovery. 🌙 Try to put away screens 30 minutes before bed and relax. Sleep on time to keep your streak!"
            }
            prompt.contains("water", ignoreCase = true) -> {
                "💧 Hydration check! Keep drinking water steadily throughout the day. Aim for 8-10 glasses or your custom water goal!"
            }
            else -> {
                "Hello! I am your AI Health Coach. 🌟 Remember, every small step count. Complete your missions today, earn Coins, level up, and build a healthier lifestyle!"
            }
        }
    }
}
