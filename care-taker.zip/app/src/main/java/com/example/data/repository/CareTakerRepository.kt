package com.example.data.repository

import com.example.data.dao.CareTakerDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

class CareTakerRepository(private val careTakerDao: CareTakerDao) {

    val userProfile: Flow<UserProfile?> = careTakerDao.getUserProfileFlow()
    val allHealthLogs: Flow<List<HealthLog>> = careTakerDao.getHealthLogsFlow()
    val achievements: Flow<List<Achievement>> = careTakerDao.getAchievementsFlow()

    suspend fun getUserProfileDirect(): UserProfile? = careTakerDao.getUserProfile()

    suspend fun saveUserProfile(profile: UserProfile) {
        careTakerDao.insertUserProfile(profile)
    }

    fun getDailyTasks(date: String): Flow<List<DailyTask>> = careTakerDao.getDailyTasksFlow(date)

    suspend fun getDailyTasksDirect(date: String): List<DailyTask> = careTakerDao.getDailyTasks(date)

    suspend fun saveDailyTask(task: DailyTask) {
        careTakerDao.insertDailyTask(task)
    }

    suspend fun saveDailyTasks(tasks: List<DailyTask>) {
        careTakerDao.insertDailyTasks(tasks)
    }

    suspend fun updateDailyTask(task: DailyTask) {
        careTakerDao.updateDailyTask(task)
    }

    suspend fun clearDailyTasksForDate(date: String) {
        careTakerDao.deleteDailyTasksForDate(date)
    }

    fun getHealthLogsFlowByType(type: String): Flow<List<HealthLog>> = careTakerDao.getHealthLogsFlowByType(type)

    suspend fun getHealthLogsByType(type: String): List<HealthLog> = careTakerDao.getHealthLogsByType(type)

    suspend fun getHealthLogsForDateAndType(date: String, type: String): List<HealthLog> = 
        careTakerDao.getHealthLogsForDateAndType(date, type)

    suspend fun addHealthLog(log: HealthLog) {
        careTakerDao.insertHealthLog(log)
    }

    suspend fun deleteHealthLog(id: Int) {
        careTakerDao.deleteHealthLogById(id)
    }

    suspend fun getAchievementsDirect(): List<Achievement> = careTakerDao.getAchievements()

    suspend fun saveAchievements(achievements: List<Achievement>) {
        careTakerDao.insertAchievements(achievements)
    }

    suspend fun updateAchievement(achievement: Achievement) {
        careTakerDao.updateAchievement(achievement)
    }
}
